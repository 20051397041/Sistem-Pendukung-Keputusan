<?php

$k21=mysqli_connect('localhost','root','','topsis');
?>